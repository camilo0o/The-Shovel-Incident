extends CharacterBody2D

signal murio

@export var vida_maxima := 2
@export var velocidad := 40.0            # el jugador va a 100
@export var rango_deteccion := 120.0     # a esta distancia empieza a perseguir
@export var rango_ataque := 26.0         # a esta distancia ataca
@export var dano := 1
@export var cooldown_ataque := 1.2       # pausa entre ataques
@export var fuerza_retroceso := 140.0    # empujón al recibir un golpe
@export_range(0.1, 0.9) var momento_golpe := 0.5  # en qué punto de la animación de ataque conecta el golpe

enum Estado { LIBRE, ATACANDO, MUERTO }

@export_group("Sonido")
@export var sonido_idle: AudioStream
@export var intervalo_sonido_min := 4.0   # segundos de silencio entre sonidos
@export var intervalo_sonido_max := 9.0

@export_group("Botín")
@export var monedas_al_morir := 1

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var colision: CollisionShape2D = $CollisionShape2D

var _audio: AudioStreamPlayer2D
var vida := 0
var estado := Estado.LIBRE
var jugador: Node2D
var puede_atacar := true
var empuje := Vector2.ZERO

var _barra_vida: ProgressBar

const MONEDA_SCENE := preload("res://scenes/moneda_pickup.tscn")

func _ready() -> void:
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING 
	add_to_group("enemigos")
	vida = vida_maxima
	_crear_barra_vida()
	_pose_reposo()
	_crear_audio()
	_bucle_sonido()


func _physics_process(delta: float) -> void:
	if not is_instance_valid(jugador):
		jugador = get_tree().get_first_node_in_group("jugador") as Node2D
		if not is_instance_valid(jugador):
			return

	var hacia_jugador := jugador.global_position - global_position
	var distancia := hacia_jugador.length()

	if estado == Estado.ATACANDO:
		velocity = Vector2.ZERO
	elif distancia > rango_deteccion or jugador.invisible:
		velocity = Vector2.ZERO
		_pose_reposo()
	elif distancia > rango_ataque:
		velocity = hacia_jugador.normalized() * velocidad
		_caminar()
	else:
		velocity = Vector2.ZERO
		_pose_reposo()
		if puede_atacar:
			_atacar()

	empuje = empuje.move_toward(Vector2.ZERO, 600.0 * delta)
	velocity += empuje
	move_and_slide()



func _atacar() -> void:
	if estado != Estado.LIBRE or not puede_atacar or not is_instance_valid(jugador):
		return
	estado = Estado.ATACANDO
	puede_atacar = false

	var anim := &"attack_right" if jugador.global_position.x >= global_position.x else &"attack_left"
	sprite.play(anim)
	var duracion := sprite.sprite_frames.get_frame_count(anim) / sprite.sprite_frames.get_animation_speed(anim)

	await get_tree().create_timer(duracion * momento_golpe, false).timeout
	if estado == Estado.MUERTO:
		return
	if is_instance_valid(jugador) and global_position.distance_to(jugador.global_position) <= rango_ataque * 1.3:
		if jugador.has_method("recibir_dano"):
			jugador.recibir_dano(dano, global_position)

	await get_tree().create_timer(duracion * (1.0 - momento_golpe), false).timeout
	if estado == Estado.MUERTO:
		return
	estado = Estado.LIBRE

	await get_tree().create_timer(cooldown_ataque, false).timeout
	if estado != Estado.MUERTO:
		puede_atacar = true



func recibir_dano(cantidad: int, origen: Vector2 = Vector2.ZERO) -> void:
	if estado == Estado.MUERTO:
		return
	vida -= cantidad
	_actualizar_barra_vida()

	if origen != Vector2.ZERO:
		empuje = (global_position - origen).normalized() * fuerza_retroceso

	if vida <= 0:
		_morir()
		return

	sprite.modulate = Color(1, 0.3, 0.3)
	await get_tree().create_timer(0.1, false).timeout
	if estado != Estado.MUERTO:
		sprite.modulate = Color.WHITE


func _morir() -> void:
	estado = Estado.MUERTO
	velocity = Vector2.ZERO
	murio.emit()
	colision.set_deferred("disabled", true)
	set_physics_process(false)
	if _barra_vida != null:
		_barra_vida.visible = false
	if _audio != null:
		_audio.stop()
	sprite.modulate = Color(1, 0.3, 0.3)
	var tween := create_tween()
	tween.tween_property(sprite, "modulate:a", 0.0, 0.4)
	tween.tween_callback(queue_free)

	GameProgress.carpi_evento.emit(&"kill")
	_soltar_moneda.call_deferred(global_position)

func _soltar_moneda(pos: Vector2) -> void:
	var escena := get_tree().current_scene
	if escena == null:
		return
	var moneda := MONEDA_SCENE.instantiate()
	moneda.cantidad = monedas_al_morir
	escena.add_child(moneda)
	moneda.global_position = pos

func _crear_audio() -> void:
	if sonido_idle == null:
		return
	_audio =  AudioStreamPlayer2D.new()
	_audio.stream = sonido_idle
	_audio.max_distance = 300.0
	add_child(_audio)

func _bucle_sonido() -> void:
	if _audio == null:
		return
	await get_tree().create_timer(randf_range(0.5, intervalo_sonido_max), false).timeout
	if estado == Estado.MUERTO:
		return
	while estado != Estado.MUERTO:
		_audio.play()
		await _audio.finished
		await get_tree().create_timer(randf_range(intervalo_sonido_min, intervalo_sonido_max), false).timeout



func _caminar() -> void:
	if sprite.animation != &"movement" or not sprite.is_playing():
		sprite.play(&"movement")


func _pose_reposo() -> void:
	if sprite.animation != &"movement" or sprite.is_playing():
		sprite.animation = &"movement"
		sprite.stop()
		sprite.frame = 0

func _crear_barra_vida() -> void:
	_barra_vida = ProgressBar.new()
	_barra_vida.min_value = 0
	_barra_vida.max_value = vida_maxima
	_barra_vida.value = vida
	_barra_vida.show_percentage = false
	_barra_vida.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var ancho := 20.0
	var alto := 4.0
	_barra_vida.custom_minimum_size = Vector2(ancho, alto)
	_barra_vida.size = Vector2(ancho, alto)
	_barra_vida.position = Vector2(-ancho / 2.0, -22.0)
	_barra_vida.z_index = 10

	var fondo := StyleBoxFlat.new()
	fondo.bg_color = Color(0.1, 0.1, 0.1, 0.85)
	var relleno := StyleBoxFlat.new()
	relleno.bg_color = Color(0.85, 0.15, 0.15)

	_barra_vida.add_theme_stylebox_override("background", fondo)
	_barra_vida.add_theme_stylebox_override("fill", relleno)

	add_child(_barra_vida)


func _actualizar_barra_vida() -> void:
	if _barra_vida == null:
		return
	_barra_vida.value = vida
