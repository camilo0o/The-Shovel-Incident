extends Control

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/garage.tscn")

func _on_options_pressed() -> void:
	print("Opciones")
	get_tree().change_scene_to_file("res://scenes/settings.tscn")

func _on_quit_pressed() -> void:
	get_tree().quit()

func _on_watch_intro_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/introduction.tscn")
